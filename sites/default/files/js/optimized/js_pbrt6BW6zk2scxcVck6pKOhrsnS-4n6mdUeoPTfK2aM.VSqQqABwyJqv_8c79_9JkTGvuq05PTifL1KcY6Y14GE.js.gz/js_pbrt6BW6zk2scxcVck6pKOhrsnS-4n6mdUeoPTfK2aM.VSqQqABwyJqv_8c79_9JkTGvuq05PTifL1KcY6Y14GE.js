/* Source and licensing information for the line(s) below can be found at http://local.sandervancamp.be/core/assets/vendor/jquery.ui/ui/data-min.js. */
/*!
 * jQuery UI :data 1.12.1
 * http://jqueryui.com
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license.
 * http://jquery.org/license
 */
!function(e){"function"==typeof define&&define.amd?define(["jquery","./version"],e):e(jQuery)}((function(e){return e.extend(e.expr[":"],{data:e.expr.createPseudo?e.expr.createPseudo((function(n){return function(t){return!!e.data(t,n)}})):function(n,t,r){return!!e.data(n,r[3])}})}));
/* Source and licensing information for the above line(s) can be found at http://local.sandervancamp.be/core/assets/vendor/jquery.ui/ui/data-min.js. */